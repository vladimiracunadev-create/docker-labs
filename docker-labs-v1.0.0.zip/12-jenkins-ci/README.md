# 12-jenkins-ci

CI/CD con Jenkins.

## 🚀 Inicio Rápido

```bash
cd 12-jenkins-ci
docker-compose up
```

Accede a http://localhost:8080 (sigue setup inicial)