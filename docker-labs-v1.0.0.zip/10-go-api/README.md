# 10-go-api

API REST en Go.

## 🚀 Inicio Rápido

```bash
cd 10-go-api
docker-compose up
```

Accede a http://localhost:8080