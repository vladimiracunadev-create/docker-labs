# 08-prometheus-grafana

Monitoreo con Prometheus y Grafana.

## 🚀 Inicio Rápido

```bash
cd 08-prometheus-grafana
docker-compose up
```

- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (admin/admin)