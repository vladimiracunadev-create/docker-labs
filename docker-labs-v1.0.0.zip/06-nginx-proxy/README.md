# 06-nginx-proxy

Reverse proxy con Nginx.

## 🚀 Inicio Rápido

```bash
cd 06-nginx-proxy
docker-compose up
```

Accede a http://localhost:8080

## ☸️ Despliegue en Kubernetes

Crear deployment para nginx.