# 09-multi-service-app

App multi-servicio: Frontend + Backend + DB.

## 🚀 Inicio Rápido

```bash
cd 09-multi-service-app
docker-compose up
```

- Frontend: http://localhost:8080
- Backend: http://localhost:3000/api