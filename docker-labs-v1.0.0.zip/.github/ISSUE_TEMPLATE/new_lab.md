---
name: Nuevo Laboratorio
about: Propón un nuevo laboratorio para docker-labs
title: "[NEW LAB] "
labels: new-lab
assignees: ''

---

**Nombre del Laboratorio**
Ej. "04-redis-cache"

**Stack Tecnológico**
Describe el stack: lenguajes, frameworks, bases de datos, etc.

**Objetivo Educativo**
¿Qué aprenderá el usuario con este lab?

**Complejidad**
- [ ] Básico
- [ ] Intermedio
- [ ] Avanzado

**¿Por qué este lab?**
Explica por qué sería útil agregarlo a docker-labs.

**Estructura Propuesta**
Describe brevemente la estructura de archivos (Dockerfile, docker-compose, código, etc.).

**Contexto Adicional**
Cualquier detalle extra.