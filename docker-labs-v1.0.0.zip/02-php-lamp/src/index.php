<?php
echo "<h1>PHP OK ✅</h1>";
echo "<p>Fecha: " . date("Y-m-d H:i:s") . "</p>";
?>