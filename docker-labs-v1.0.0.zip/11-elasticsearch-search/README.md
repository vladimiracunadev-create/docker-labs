# 11-elasticsearch-search

Búsqueda con Elasticsearch.

## 🚀 Inicio Rápido

```bash
cd 11-elasticsearch-search
docker-compose up
```

Accede a http://localhost:8000/docs