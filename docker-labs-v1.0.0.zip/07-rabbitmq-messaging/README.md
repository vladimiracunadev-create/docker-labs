# 07-rabbitmq-messaging

Mensajería con RabbitMQ.

## 🚀 Inicio Rápido

```bash
cd 07-rabbitmq-messaging
docker-compose up -d
npm run producer
npm run consumer
```

Management UI: http://localhost:15672 (user/pass)